package app.ledge

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** Only used for the double-tap-to-lock gesture. It ignores all events. */
class LockService : AccessibilityService() {
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    companion object {
        private var inst: LockService? = null
        /** Returns false when the service isn't enabled yet. */
        fun lock(): Boolean = inst?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) == true
    }
}
