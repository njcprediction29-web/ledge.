package app.ledge

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.location.LocationManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.provider.CalendarContract
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.exp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Ledge() } }
    }
}

class App(val label: String, val pkg: String, val icon: ImageBitmap, val avg: Int)

/** All settings live here, persisted as strings. */
class Cfg(private val sp: SharedPreferences) {
    private val m: SnapshotStateMap<String, String> = mutableStateMapOf<String, String>().apply { sp.all.forEach { (k, v) -> put(k, v.toString()) } }
    operator fun get(k: String, d: String = "") = m[k] ?: d
    operator fun set(k: String, v: String) { m[k] = v; sp.edit().putString(k, v).apply() }
    fun on(k: String, d: Boolean = false) = get(k, d.toString()) == "true"
    fun flip(k: String, d: Boolean = false) = set(k, (!on(k, d)).toString())
    fun cycle(k: String, opts: List<String>, d: String) { set(k, opts[(opts.indexOf(get(k, d)) + 1) % opts.size]) }
    fun folders(): Map<String, List<String>> = get("folders").split(";").filter { it.contains("=") }.associate {
        val (n, v) = it.split("=", limit = 2); n to v.split(",").filter { x -> x.isNotEmpty() }
    }
    fun setFolders(f: Map<String, List<String>>) = set("folders", f.entries.joinToString(";") { it.key + "=" + it.value.joinToString(",") })
    fun code() = listOf(get("theme", "Plain"), get("font", "Sans"), get("shape", "Square"), get("icons", "Color"), get("accent", "FFFFFFFF"), get("scrim", "25"), get("bold", "false")).joinToString("|")
    fun applyTheme(c: String): Boolean {
        val p = c.trim().split("|")
        if (p.size != 7 || p[4].toLongOrNull(16) == null || p[5].toIntOrNull() == null) return false
        listOf("theme", "font", "shape", "icons", "accent", "scrim", "bold").forEachIndexed { i, k -> set(k, p[i]) }
        return true
    }
}

val THEMES = listOf(
    "Plain|Sans|Square|Color|FFFFFFFF|25|false", "Mist|Sans|Circle|Mono|FFBFD7EA|35|false",
    "Forest|Serif|Square|Color|FFA7D7A0|30|false", "Cozy|Serif|Circle|Dots|FFFFC38A|40|true",
    "Night|Mono|Square|Dots|FF8FA4FF|50|false"
)
val FONTS = listOf("Sans", "Serif", "Mono", "Script")
val STYLES = listOf("Color", "Dots", "Mono")

fun loadApps(ctx: Context): List<App> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != ctx.packageName }.map {
        val small = it.loadIcon(pm).toBitmap(8, 8)
        var r = 0; var g = 0; var b = 0
        for (x in 0 until 8) for (y in 0 until 8) { val c = small.getPixel(x, y); r += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255 }
        App(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(96, 96).asImageBitmap(),
            (0xFF shl 24) or ((r / 64) shl 16) or ((g / 64) shl 8) or (b / 64))
    }.filter { it.label.isNotBlank() }.sortedBy { it.label.lowercase() }
}

fun nextEvent(ctx: Context): String? {
    val now = System.currentTimeMillis()
    val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
    ContentUris.appendId(b, now); ContentUris.appendId(b, now + 86_400_000L)
    val cols = arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN)
    return try {
        ctx.contentResolver.query(b.build(), cols, null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
            if (c.moveToFirst()) "${c.getString(0)} at " + java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(c.getLong(1)) else null
        }
    } catch (e: Exception) { null }
}

/** Current temperature from open-meteo.com, using your last known coarse location. */
fun weather(ctx: Context): String? {
    return try {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val l = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time } ?: return null
        val u = "https://api.open-meteo.com/v1/forecast?latitude=${l.latitude}&longitude=${l.longitude}&current=temperature_2m"
        "${JSONObject(URL(u).readText()).getJSONObject("current").getDouble("temperature_2m").roundToInt()}°"
    } catch (e: Exception) { null }
}

@Composable
fun Ledge() {
    val ctx = LocalContext.current
    val act = ctx as ComponentActivity
    val cfg = remember { Cfg(ctx.getSharedPreferences("ledge", Context.MODE_PRIVATE)) }
    val apps = remember { loadApps(ctx) }
    var mode by remember { mutableStateOf("home") } // home, settings, f:<folder>, or a letter
    var query by remember { mutableStateOf("") }
    var next by remember { mutableStateOf<String?>(null) }
    var wx by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableStateOf(0) }
    var now by remember { mutableStateOf(LocalTime.now()) }
    var menu by remember { mutableStateOf<App?>(null) }
    var nudge by remember { mutableStateOf<String?>(null) }
    var phones by remember { mutableStateOf(false) }

    val accent = Color(cfg["accent", "FFFFFFFF"].toLongOrNull(16) ?: 0xFFFFFFFF)
    val font = when (cfg["font", "Sans"]) { "Serif" -> FontFamily.Serif; "Mono" -> FontFamily.Monospace; "Script" -> FontFamily.Cursive; else -> FontFamily.SansSerif }
    val ts = TextStyle(color = accent, fontFamily = font, shadow = Shadow(Color.Black.copy(alpha = .6f), Offset(0f, 2f), 6f))
    val circle = cfg["shape", "Square"] == "Circle"
    val hasCal = tick >= 0 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
    val hasLoc = tick >= 0 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    val askPerms = { perms.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.ACCESS_COARSE_LOCATION)) }
    val music = remember(apps) {
        val s = ctx.packageManager.queryIntentActivities(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC), 0).map { it.activityInfo.packageName }.toSet()
        apps.filter { it.pkg in s }.take(3)
    }

    LaunchedEffect(Unit) { while (true) { now = LocalTime.now(); delay(15_000) } }
    LaunchedEffect(cfg.on("plan", true), hasCal, mode) { next = if (cfg.on("plan", true) && hasCal) withContext(Dispatchers.IO) { nextEvent(ctx) } else null }
    LaunchedEffect(cfg.on("wx"), hasLoc, mode) { wx = if (cfg.on("wx") && hasLoc) withContext(Dispatchers.IO) { weather(ctx) } else null }
    LaunchedEffect(cfg.on("hideBar")) {
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        if (cfg.on("hideBar")) c.hide(WindowInsetsCompat.Type.statusBars()) else c.show(WindowInsetsCompat.Type.statusBars())
    }
    // Plug and play: know when headphones or speakers connect.
    DisposableEffect(Unit) {
        val am = ctx.getSystemService(AudioManager::class.java)
        val types = listOf(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_USB_HEADSET)
        fun chk() { phones = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in types } }
        val cb = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(d: Array<out AudioDeviceInfo>) = chk()
            override fun onAudioDevicesRemoved(d: Array<out AudioDeviceInfo>) = chk()
        }
        chk(); am.registerAudioDeviceCallback(cb, null)
        onDispose { am.unregisterAudioDeviceCallback(cb) }
    }
    // Usage breaker: when you come back from an app you opened here, say how long you were away.
    DisposableEffect(Unit) {
        val o = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                val lim = cfg["limit", "0"].toIntOrNull() ?: 0
                val t = cfg["lastT", "0"].toLongOrNull() ?: 0L
                val m = (System.currentTimeMillis() - t) / 60000
                if (lim > 0 && t > 0 && m >= lim) nudge = "You spent $m min in ${cfg["lastApp"]}. Time for a break?"
                cfg["lastT"] = "0"
            }
        }
        act.lifecycle.addObserver(o); onDispose { act.lifecycle.removeObserver(o) }
    }
    BackHandler(enabled = mode != "home" || query.isNotEmpty() || menu != null) { if (menu != null) menu = null else { mode = "home"; query = "" } }

    val open: (App) -> Unit = { a ->
        cfg["lastApp"] = a.label; cfg["lastT"] = System.currentTimeMillis().toString()
        ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.let { ctx.startActivity(it) }
        mode = "home"; query = ""
    }
    val letters = remember(apps) { listOf("☆") + apps.map { it.label.first().uppercaseChar().toString() }.distinct() + "°" }
    val folders = cfg.folders()
    val favs = cfg["favs"].split(",").filter { it.isNotEmpty() }

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (cfg["scrim", "25"].toIntOrNull() ?: 25) / 100f)).systemBarsPadding()) {
        when {
            mode == "settings" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 40.dp)) {
                Text("Ledge settings", style = ts.copy(fontSize = 26.sp))
                Spacer(Modifier.height(12.dp))
                val clip = ctx.getSystemService(ClipboardManager::class.java)
                Opt("Theme", cfg["theme", "Plain"], ts) { val i = THEMES.indexOfFirst { it.startsWith(cfg["theme", "Plain"] + "|") }; cfg.applyTheme(THEMES[(i + 1) % THEMES.size]) }
                Opt("Font", cfg["font", "Sans"], ts) { cfg.cycle("font", FONTS, "Sans") }
                Opt("Icon shape", cfg["shape", "Square"], ts) { cfg.cycle("shape", listOf("Square", "Circle"), "Square") }
                Opt("Icon style", cfg["icons", "Color"], ts) { cfg.cycle("icons", STYLES, "Color") }
                Opt("Clock size", cfg["csize", "M"], ts) { cfg.cycle("csize", listOf("S", "M", "L"), "M") }
                Toggle("Clock 24-hour", cfg.on("c24", true), ts) { cfg.flip("c24", true) }
                Toggle("Bold clock", cfg.on("bold"), ts) { cfg.flip("bold") }
                Toggle("Plan your day (calendar)", cfg.on("plan", true), ts) { cfg.flip("plan", true); if (!hasCal) askPerms() }
                Toggle("Weather (needs location)", cfg.on("wx"), ts) { cfg.flip("wx"); if (!hasLoc) askPerms() }
                Toggle("Hide status bar", cfg.on("hideBar"), ts) { cfg.flip("hideBar") }
                Toggle("Plug and play (music apps with headphones)", cfg.on("plug", true), ts) { cfg.flip("plug", true) }
                Opt("Usage breaker (minutes)", cfg["limit", "0"].let { if (it == "0") "Off" else it }, ts) { cfg.cycle("limit", listOf("0", "15", "30", "60"), "0") }
                Toggle("Double-tap letters to lock", cfg.on("lock", true), ts) { cfg.flip("lock", true) }
                Link("Turn on the Ledge lock service", ts) { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                Link("Copy my theme code (share it)", ts) { clip.setPrimaryClip(ClipData.newPlainText("theme", cfg.code())) }
                Link("Paste a theme code", ts) { clip.primaryClip?.getItemAt(0)?.text?.let { cfg.applyTheme(it.toString()) } }
                Link("Set Ledge as your home app", ts) { ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                Link("Done", ts) { mode = "home" }
            }
            mode == "home" -> Column(Modifier.fillMaxSize().padding(start = 24.dp, end = 56.dp, bottom = 12.dp)) {
                Spacer(Modifier.height(72.dp))
                val pages = if (cfg.on("wx")) 2 else 1
                val pager = rememberPagerState(pageCount = { pages })
                HorizontalPager(pager, Modifier.height(130.dp)) { p ->
                    Column {
                        if (p == 0) {
                            val size = when (cfg["csize", "M"]) { "S" -> 40; "L" -> 68; else -> 52 }.sp
                            Text(now.format(DateTimeFormatter.ofPattern(if (cfg.on("c24", true)) "HH:mm" else "h:mm")),
                                style = ts.copy(fontSize = size, fontWeight = if (cfg.on("bold")) FontWeight.Bold else FontWeight.Light))
                            Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, MMM d")), style = ts.copy(fontSize = 15.sp))
                            next?.let { Text("Next: $it", style = ts.copy(fontSize = 13.sp), modifier = Modifier.padding(top = 4.dp)) }
                        } else {
                            Text(wx ?: "–", style = ts.copy(fontSize = 52.sp, fontWeight = FontWeight.Light))
                            Text(if (wx == null) "Allow location to see weather" else "Outside now", style = ts.copy(fontSize = 15.sp))
                        }
                    }
                }
                nudge?.let { Text(it, style = ts.copy(fontSize = 14.sp), modifier = Modifier.clickable { nudge = null }.padding(bottom = 8.dp)) }
                val base = favs.mapNotNull { f -> apps.find { it.pkg == f } }.ifEmpty { apps.take(6) }
                val shown = if (query.isNotBlank()) apps.filter { it.label.contains(query, true) }
                else if (phones && cfg.on("plug", true)) (music + base).distinctBy { it.pkg } else base
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.Bottom) {
                    items(shown, key = { it.pkg }) { a -> AppRow(a, cfg, circle, ts, { open(a) }, { menu = a }) }
                    if (query.isBlank()) items(folders.keys.toList()) { n ->
                        Text("▸ $n", style = ts.copy(fontSize = 18.sp), modifier = Modifier.fillMaxWidth().clickable { mode = "f:$n" }.padding(vertical = 12.dp))
                    }
                }
                BasicTextField(query, { query = it }, singleLine = true, textStyle = ts.copy(fontSize = 18.sp), cursorBrush = SolidColor(accent),
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    decorationBox = { inner -> Box { if (query.isEmpty()) Text("Search apps", style = ts.copy(fontSize = 18.sp, color = accent.copy(alpha = .6f))); inner() } })
            }
            else -> Column(Modifier.fillMaxSize().padding(start = 24.dp, end = 56.dp, top = 120.dp)) {
                val isF = mode.startsWith("f:")
                Text(mode.removePrefix("f:"), style = ts.copy(fontSize = 15.sp), modifier = Modifier.padding(start = 2.dp, bottom = 8.dp))
                val list = if (isF) (folders[mode.removePrefix("f:")] ?: emptyList()).mapNotNull { f -> apps.find { it.pkg == f } }
                else apps.filter { it.label.first().uppercaseChar().toString() == mode }
                LazyColumn { items(list, key = { it.pkg }) { a -> AppRow(a, cfg, circle, ts, { open(a) }, { menu = a }) } }
            }
        }
        if (mode != "settings") Rail(letters, ts, Modifier.align(Alignment.BottomEnd).padding(bottom = 64.dp).fillMaxHeight(.54f),
            onPick = { mode = when (it) { "☆" -> "home"; "°" -> "settings"; else -> it } },
            onDouble = { if (cfg.on("lock", true) && !LockService.lock()) ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        menu?.let { a ->
            Column(Modifier.align(Alignment.Center).padding(32.dp).clip(RoundedCornerShape(20.dp)).background(Color.Black.copy(alpha = .85f)).padding(20.dp)) {
                Text(a.label, style = ts.copy(fontSize = 18.sp))
                Link(if (a.pkg in favs) "Remove from favorites" else "Add to favorites", ts) {
                    cfg["favs"] = (if (a.pkg in favs) favs - a.pkg else favs + a.pkg).joinToString(","); menu = null }
                val cur = cfg["ov.${a.pkg}", cfg["icons", "Color"]]
                Link("Icon style: $cur (tap to change)", ts) { cfg["ov.${a.pkg}"] = STYLES[(STYLES.indexOf(cur) + 1) % STYLES.size] }
                folders.keys.forEach { n -> Link("Add to folder $n", ts) { cfg.setFolders(folders + (n to (folders[n]!! + a.pkg).distinct())); menu = null } }
                Link("New folder", ts) { val n = "Folder ${folders.size + 1}"; cfg.setFolders(folders + (n to listOf(a.pkg))); menu = null }
                Link("Remove from folders", ts) { cfg.setFolders(folders.mapValues { it.value - a.pkg }.filter { it.value.isNotEmpty() }); menu = null }
                Link("Close", ts) { menu = null }
            }
        }
    }
}

@Composable fun Toggle(label: String, on: Boolean, ts: TextStyle, set: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(label, style = ts.copy(fontSize = 16.sp), modifier = Modifier.weight(1f)); Switch(on, { set() })
    }
}
@Composable fun Opt(label: String, value: String, ts: TextStyle, next: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = next).padding(vertical = 12.dp), Arrangement.SpaceBetween) {
        Text(label, style = ts.copy(fontSize = 16.sp)); Text(value, style = ts.copy(fontSize = 16.sp))
    }
}
@Composable fun Link(t: String, ts: TextStyle, f: () -> Unit) = Text(t, style = ts.copy(fontSize = 16.sp), modifier = Modifier.clickable(onClick = f).padding(vertical = 11.dp))

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppRow(a: App, cfg: Cfg, circle: Boolean, ts: TextStyle, onOpen: () -> Unit, onLong: () -> Unit) {
    val style = cfg["ov.${a.pkg}", cfg["icons", "Color"]]
    Row(Modifier.fillMaxWidth().combinedClickable(onClick = onOpen, onLongClick = onLong).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp), Alignment.Center) {
            if (style == "Dots") Box(Modifier.size(16.dp).clip(CircleShape).background(Color(a.avg)))
            else Image(a.icon, null, Modifier.fillMaxSize().clip(if (circle) CircleShape else RoundedCornerShape(11.dp)),
                colorFilter = if (style == "Mono") ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) }) else null)
        }
        Spacer(Modifier.width(22.dp))
        Text(a.label, style = ts.copy(fontSize = 18.sp), maxLines = 1)
    }
}

@Composable
fun Rail(letters: List<String>, ts: TextStyle, modifier: Modifier, onPick: (String) -> Unit, onDouble: () -> Unit) {
    val d = LocalDensity.current.density
    var h by remember { mutableStateOf(1f) }
    var y by remember { mutableStateOf<Float?>(null) }
    var sel by remember { mutableStateOf("") }
    val n = letters.size
    fun pick(py: Float) { val i = ((py / h) * n).toInt().coerceIn(0, n - 1); sel = letters[i]; onPick(sel) }
    Box(modifier.width(48.dp).onSizeChanged { h = it.height.toFloat() }
        .pointerInput(letters) { detectTapGestures(onDoubleTap = { onDouble() }, onTap = { y = null; pick(it.y) }) }
        .pointerInput(letters) {
            detectDragGestures(onDragStart = { y = it.y; pick(it.y) }, onDragEnd = { y = null }, onDragCancel = { y = null },
                onDrag = { c, _ -> y = c.position.y; pick(c.position.y) })
        }) {
        Column(Modifier.fillMaxHeight().padding(end = 8.dp), Arrangement.SpaceBetween, Alignment.End) {
            letters.forEachIndexed { i, l ->
                val dy = y?.let { it - (i + .5f) * h / n } ?: 9999f
                val dx = -78f * d * exp(-(dy * dy) / (2f * 44f * d * 44f * d))
                Text(l, style = ts.copy(fontSize = 14.sp), modifier = Modifier.graphicsLayer { translationX = dx })
            }
        }
        y?.let { fy ->
            Box(Modifier.offset { IntOffset((-150f * d).toInt(), (fy - 29f * d).toInt()) }.size(58.dp).clip(CircleShape).background(Color(0xCCB4ACA4)), Alignment.Center) {
                Text(sel, style = ts.copy(fontSize = 28.sp))
            }
        }
    }
}
